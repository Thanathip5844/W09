        <ul class="nav nav-tabs">
            <li><a href="index.php">หน้าหลัก</a></li>
            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                    จัดการข้อมูลพื้นฐาน<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="title_list.php">คำนำหน้าชื่อ</a></li>
                    <li><a href="tools_list.php">เครื่องมือ</a></li>
                    <li><a href="project_status_list.php">สถานะโครงงาน</a></li>
                    <li><a href="program_list.php">สาขาวิชา</a></li>
                    <li><a href="project_type_list.php">ประเภทโครงงาน</a></li>
                    <li class="divider"></li>
                    <li><a href="lecturer_list.php">ข้อมูลอาจารย์</a></li>
                    <li><a href="student_list.php">ข้อมูลนักศึกษา</a></li>
                </ul>    
            </li>
            <li>
                <a href="#">จัดการโครงงาน</a>
            </li>
        </ul>
